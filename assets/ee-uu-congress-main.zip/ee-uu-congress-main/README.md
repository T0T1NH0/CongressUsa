# ee-uu-congress
A mockup made by html, css and javascript
