

 const filter = (apiData, checkboxValue) => {
    console.log(apiData, checkboxValue.value)
 }

 export default filter