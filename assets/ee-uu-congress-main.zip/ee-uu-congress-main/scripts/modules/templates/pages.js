 
export const PAGES = {
    HOUSE: "house",
    SENATE: "senate"
}
